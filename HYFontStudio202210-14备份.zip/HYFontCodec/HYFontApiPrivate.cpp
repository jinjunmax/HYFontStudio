#include "stdafx.h"
#include "HYFontApiPrivate.h"


void Test()
{

}