#ifndef HY_FONT_API_PRIVATE
#define HY_FONT_API_PRIVATE

#include "HYFontCodecDef.h"




#endif