#include "StdAfx.h"
#include "HYPrep.h"

namespace HYFONTCODEC
{
	CHYPrep::CHYPrep(void)
	{
	}	// end of CHYPrep::CHYPrep()

	CHYPrep::~CHYPrep(void)
	{
		vtPrep.clear();

	}	// end of CHYPrep::~CHYPrep()

	void CHYPrep::SetDefault()
	{
		vtPrep.clear();

	}	// end of void CHYPrep::SetDefault()
}
