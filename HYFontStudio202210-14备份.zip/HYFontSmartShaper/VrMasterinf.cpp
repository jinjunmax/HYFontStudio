#include "stdafx.h"
#include "VrMasterinf.h"

CVrMasterinf::CVrMasterinf()
{
}	// end of CVrMasterinf::CVrMasterinf()

CVrMasterinf::~CVrMasterinf()
{

}	// end of CVrMasterinf::~CVrMasterinf()
