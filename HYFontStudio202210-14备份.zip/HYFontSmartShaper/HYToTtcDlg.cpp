// HYToTtcDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HYFontSmartShaper.h"
#include "HYToTtcDlg.h"


// CHYToTtcDlg dialog

IMPLEMENT_DYNAMIC(CHYToTtcDlg, CDialog)

CHYToTtcDlg::CHYToTtcDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHYToTtcDlg::IDD, pParent)
{

}

CHYToTtcDlg::~CHYToTtcDlg()
{
}

void CHYToTtcDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CHYToTtcDlg, CDialog)
END_MESSAGE_MAP()


// CHYToTtcDlg message handlers
