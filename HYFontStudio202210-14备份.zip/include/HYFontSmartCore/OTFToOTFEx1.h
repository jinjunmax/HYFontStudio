#pragma once
#include "OTFToOTF.h"

class AFX_EXT_CLASS COTFToOTFEx1 : public COTFToOTF
{
public:
	COTFToOTFEx1(void);
	~COTFToOTFEx1(void);

};
