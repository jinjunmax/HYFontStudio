#pragma once
#include "ttftootf.h"

class AFX_EXT_CLASS COTFToTTF :	public CTTFToOTF
{
public:
	COTFToTTF(void);
	virtual ~COTFToTTF(void);


	int OTFToTTFTest(int i);
};
